--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.1
-- Dumped by pg_dump version 14.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'Russian_Russia.1251';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: adminpack; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS adminpack WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION adminpack; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION adminpack IS 'administrative functions for PostgreSQL';


--
-- Name: fn_image_ins(text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_image_ins(arg_link text, arg_alt text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
declare
    v_id int;
begin
    perform z_exception_if(arg_link is null, 'Не передано значение ссылки');

    insert into t_image as i (
        link,
        alt
    ) values (
        arg_link,
        arg_alt
    ) returning i.id into v_id;

    return v_id;
end;
$$;


ALTER FUNCTION public.fn_image_ins(arg_link text, arg_alt text) OWNER TO postgres;

--
-- Name: FUNCTION fn_image_ins(arg_link text, arg_alt text); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.fn_image_ins(arg_link text, arg_alt text) IS 'Изображения. Создание';


--
-- Name: fn_image_tag_get(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_image_tag_get(arg_tag text) RETURNS TABLE(id integer, link text, alt text, created_at timestamp without time zone, updated_at timestamp without time zone, tags json)
    LANGUAGE plpgsql
    AS $$
declare
begin
    if arg_tag = '' then
        return query
            select
                i.id,
                i.link,
                i.alt,
                i.created_at,
                i.updated_at,
                i.tags
            from v_image i;
    else
        return query
            select
                i.id,
                i.link,
                i.alt,
                i.created_at,
                i.updated_at,
                i.tags
            from v_image i
            join t_image_tag it on it.image_id = i.id
            where it.name = arg_tag;
    end if;
end;
$$;


ALTER FUNCTION public.fn_image_tag_get(arg_tag text) OWNER TO postgres;

--
-- Name: FUNCTION fn_image_tag_get(arg_tag text); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.fn_image_tag_get(arg_tag text) IS 'Изображения. Поиск по тегу';


--
-- Name: fn_image_tag_ins(integer, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_image_tag_ins(arg_image_id integer, arg_tag text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
declare
    v_id int;
begin
    perform z_exception_if(arg_image_id is null, 'Не передан код изображения');
    perform z_exception_if(arg_tag      is null, 'Не передано значение тега');

    perform z_exception_if(
        not exists(
            select 1
            from t_image i
            where i.id = arg_image_id
        ),
        'Изображеия с кодом %L не существует',
        arg_image_id::text
    );

    perform z_exception_if(
        exists(
            select 1
            from t_image_tag it
            where it.image_id = arg_image_id and
            it.name = arg_tag
        ),
        'Тег %L уже существует',
         arg_tag::text
    );

    insert into t_image_tag as it (
        name,
        image_id
    ) values (
        arg_tag,
        arg_image_id
    ) returning it.id into v_id;

    return v_id;
end;
$$;


ALTER FUNCTION public.fn_image_tag_ins(arg_image_id integer, arg_tag text) OWNER TO postgres;

--
-- Name: FUNCTION fn_image_tag_ins(arg_image_id integer, arg_tag text); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.fn_image_tag_ins(arg_image_id integer, arg_tag text) IS 'Теги изображений. Создание';


--
-- Name: z_exception_if(boolean, text, text[]); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.z_exception_if(arg_condition boolean, arg_message text, VARIADIC arg_params text[] DEFAULT ARRAY[]::text[]) RETURNS void
    LANGUAGE plpgsql IMMUTABLE
    AS $$
begin
    if arg_condition then
        raise exception 'USER_ERROR %', format(arg_message, variadic arg_params);
    end if;
end;
$$;


ALTER FUNCTION public.z_exception_if(arg_condition boolean, arg_message text, VARIADIC arg_params text[]) OWNER TO postgres;

--
-- Name: FUNCTION z_exception_if(arg_condition boolean, arg_message text, VARIADIC arg_params text[]); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.z_exception_if(arg_condition boolean, arg_message text, VARIADIC arg_params text[]) IS 'Выбрасывает исключение по условию';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: t_image; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.t_image (
    id integer NOT NULL,
    link text NOT NULL,
    alt text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.t_image OWNER TO postgres;

--
-- Name: t_image_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.t_image_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.t_image_id_seq OWNER TO postgres;

--
-- Name: t_image_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.t_image_id_seq OWNED BY public.t_image.id;


--
-- Name: t_image_tag; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.t_image_tag (
    id integer NOT NULL,
    name text NOT NULL,
    image_id integer NOT NULL
);


ALTER TABLE public.t_image_tag OWNER TO postgres;

--
-- Name: t_image_tag_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.t_image_tag_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.t_image_tag_id_seq OWNER TO postgres;

--
-- Name: t_image_tag_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.t_image_tag_id_seq OWNED BY public.t_image_tag.id;


--
-- Name: v_image; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.v_image AS
 SELECT i.id,
    i.link,
    i.alt,
    i.created_at,
    i.updated_at,
    COALESCE(( SELECT json_agg(itags.*) AS json_agg
           FROM ( SELECT ti.name
                   FROM public.t_image_tag ti
                  WHERE (ti.image_id = i.id)) itags), '[{}]'::json) AS tags
   FROM public.t_image i
  ORDER BY i.updated_at DESC;


ALTER TABLE public.v_image OWNER TO postgres;

--
-- Name: VIEW v_image; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON VIEW public.v_image IS 'Изображения';


--
-- Name: t_image id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_image ALTER COLUMN id SET DEFAULT nextval('public.t_image_id_seq'::regclass);


--
-- Name: t_image_tag id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_image_tag ALTER COLUMN id SET DEFAULT nextval('public.t_image_tag_id_seq'::regclass);


--
-- Data for Name: t_image; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.t_image (id, link, alt, created_at, updated_at) FROM stdin;
\.
COPY public.t_image (id, link, alt, created_at, updated_at) FROM '$$PATH$$/3329.dat';

--
-- Data for Name: t_image_tag; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.t_image_tag (id, name, image_id) FROM stdin;
\.
COPY public.t_image_tag (id, name, image_id) FROM '$$PATH$$/3331.dat';

--
-- Name: t_image_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.t_image_id_seq', 9, true);


--
-- Name: t_image_tag_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.t_image_tag_id_seq', 12, true);


--
-- Name: t_image t_image_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_image
    ADD CONSTRAINT t_image_pkey PRIMARY KEY (id);


--
-- Name: t_image_tag t_image_tag_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_image_tag
    ADD CONSTRAINT t_image_tag_pkey PRIMARY KEY (id);


--
-- Name: fki_fc_image_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_fc_image_id ON public.t_image_tag USING btree (image_id);


--
-- Name: t_image_tag t_image_tag_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_image_tag
    ADD CONSTRAINT t_image_tag_fkey FOREIGN KEY (image_id) REFERENCES public.t_image(id) ON DELETE CASCADE NOT VALID;


--
-- PostgreSQL database dump complete
--

